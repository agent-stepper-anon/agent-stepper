#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# URL Variables
TASK_1_URL="https://forms.gle/iawZPUP1xErQBPwb8"
TASK_2_URL="https://forms.gle/d617z9QkasKM89fr8"
TASK_3_URL="https://forms.gle/ahXJ3wbafLJ69qu49"
FEEDBACK_URL="https://forms.gle/8CHCwiMNuNv2yEin8"

# Store the original directory
ORIGINAL_DIR=$(pwd)

# Function to wait for any key press
wait_for_key() {
    local message="$1"
    echo -e "${YELLOW}${message}${NC}"
    echo -e "${BLUE}Press any key to continue...${NC}"
    read -n 1 -s -r
    echo ""
}

# Function to ensure Docker is running
ensure_docker_running() {
    echo -e "${GREEN}Checking if Docker is running...${NC}"
    if ! docker info > /dev/null 2>&1; then
        echo -e "${RED}Docker is not running.${NC}"
        echo -e "${YELLOW}Please start Docker Desktop and press any key when ready.${NC}"
        read -n 1 -s -r
        # Recheck after user input
        if ! docker info > /dev/null 2>&1; then
            echo -e "${RED}Docker still not running. Exiting script.${NC}"
            exit 1
        fi
    fi
    echo -e "${GREEN}Docker is running.${NC}"
}

# Function to run command and handle errors
run_command() {
    local cmd="$1"
    local desc="$2"
    echo -e "${GREEN}Running: ${desc}${NC}"
    eval "$cmd" || echo -e "${RED}Error running ${desc}. Continuing anyway.${NC}"
    # Return to original directory after command execution
    cd "$ORIGINAL_DIR" || echo -e "${RED}Error returning to original directory. Continuing anyway.${NC}"
}

# Start of script
echo -e "${BLUE}Welcome to the User Study Session Script.${NC}"

# Step 1: Ask for group
while true; do
    echo -e "${YELLOW}Is the participant in group A or B? (Enter A or B)${NC}"
    read -r group
    group=$(echo "$group" | tr '[:lower:]' '[:upper:]')
    if [[ "$group" == "A" || "$group" == "B" ]]; then
        break
    fi
    echo -e "${RED}Invalid input. Please enter A or B.${NC}"
done

echo -e "${GREEN}Participant is in group ${group}.${NC}"

# Step 2: Ensure Docker is running
ensure_docker_running

# Step 3: Open trajectory examples
echo -e "${GREEN}Opening trajectory examples...${NC}"
if [[ "$group" == "A" ]]; then
    run_command "cd agent-debugger-demo && ./start-demo.sh" "agent-debugger-demo/start-demo.sh"
else
    run_command "code \"Trajectory logs\"/\"Example SWE-Agent Log\"/6d0fcc" "code for group B example"
fi

# Step 4: Open Keynote file
run_command "open -a Keynote \"User Study Welcome.key\"" "Opening User Study Welcome.key in Keynote"

# Step 5: Wait for key to open Task 1 questionnaire and trajectory
wait_for_key "Next: Open Task 1 questionnaire and trajectory."
open "$TASK_1_URL" || echo -e "${RED}Error opening Task 1 URL. Please open $TASK_1_URL manually.${NC}"
if [[ "$group" == "A" ]]; then
    run_command "cd agent-debugger-demo && docker compose down" "docker compose down for group A"
    run_command "cd agent-debugger-demo && ./start-demo.sh" "agent-debugger-demo/start-demo.sh for Task 1"
else
    run_command "code \"Trajectory logs\"/\"Task 1 Trajectory\"/52d1ca" "code for group B Task 1"
fi

# Step 6: Wait for key to close Task 1
if [[ "$group" == "A" ]]; then
    wait_for_key "Next: Close Task 1 (if group A, run docker compose down)."
    run_command "cd agent-debugger-demo && docker compose down" "docker compose down for group A"
fi

# Step 7: Wait for key to open Task 2 questionnaire and trajectory
wait_for_key "Next: Open Task 2 questionnaire and trajectory."
open "$TASK_2_URL" || echo -e "${RED}Error opening Task 2 URL. Please open $TASK_2_URL manually.${NC}"
if [[ "$group" == "A" ]]; then
    run_command "cd agent-debugger-demo && ./start-demo.sh" "agent-debugger-demo/start-demo.sh for Task 2"
else
    run_command "code \"Trajectory logs\"/\"RepairAgent Trajectory\"" "code for group B Task 2"
fi

# Step 8: Wait for key to close Task 2
if [[ "$group" == "A" ]]; then
    wait_for_key "Next: Close Task 2 (if group A, run docker compose down)."
    run_command "cd agent-debugger-demo && docker compose down" "docker compose down for group A"
fi

# Step 9: Wait for key to open Task 3 questionnaire and trajectory
wait_for_key "Next: Open Task 3 questionnaire and trajectory."
open "$TASK_3_URL" || echo -e "${RED}Error opening Task 3 URL. Please open $TASK_3_URL manually.${NC}"
if [[ "$group" == "A" ]]; then
    run_command "cd agent-debugger-demo && ./start-demo.sh" "agent-debugger-demo/start-demo.sh for Task 3"
else
    run_command "code \"Trajectory logs\"/\"ExecutionAgent Trajectory\"" "code for group B Task 3"
fi

# Step 10: Wait for key to close Task 3
if [[ "$group" == "A" ]]; then
    wait_for_key "Next: Close Task 3 (if group A, run docker compose down)."
    run_command "cd agent-debugger-demo && docker compose down" "docker compose down for group A"
fi

# Step 11: If group A, wait for key to open feedback questionnaire
if [[ "$group" == "A" ]]; then
    wait_for_key "Next: Open Agent Debugger Feedback Questionnaire."
    open "$FEEDBACK_URL" || echo -e "${RED}Error opening Feedback URL. Please open $FEEDBACK_URL manually.${NC}"
fi

# Step 12: Exit
echo -e "${GREEN}User study session complete. Exiting.${NC}"
exit 0