#!/bin/bash

# Function to print colored output
print_color() {
    local color=$1
    local message=$2
    case $color in
        "green")  echo -e "\033[32m$message\033[0m" ;;
        "red")    echo -e "\033[31m$message\033[0m" ;;
        "yellow") echo -e "\033[33m$message\033[0m" ;;
        *)        echo "$message" ;;
    esac
}

print_color "yellow" "Welcome to the LLM Agent Debugger User Study Demo Setup!"

# Check if docker and docker-compose are installed
if ! command -v docker &> /dev/null ; then
    print_color "red" "Error: Docker and/or docker-compose not found. Please install them first."
    print_color "yellow" "Visit https://docs.docker.com/get-docker/ for installation instructions."
    exit 1
fi

# Check if docker-compose.yml exists
if [ ! -f "docker-compose.yml" ]; then
    print_color "red" "Error: docker-compose.yml not found in the current directory."
    exit 1
fi

# Start docker-compose
print_color "yellow" "\nStarting the demo..."
if ! docker compose up -d --build; then
    print_color "red" "Error: Failed to start the demo."
    exit 1
fi

print_color "green" "\nDemo is running at http://localhost:8080"
print_color "yellow" "To review interactive logs, use: docker logs -f <container_name>"

# Instructions for accessing the demo
print_color "yellow" "\nHow to access the demo:"
print_color "yellow" "If the demo is running on this machine, open http://localhost:8080 in your browser."
print_color "yellow" "If the demo is running on a remote machine, set up an SSH tunnel first:"
print_color "yellow" "1. Open a new terminal on your local machine."
print_color "yellow" "2. Run: ssh -L 8080:localhost:8080 -L 4567:localhost:4567 <remote-host>"
print_color "yellow" "3. Keep the terminal open to maintain the SSH tunnel."
print_color "yellow" "4. Then, open http://localhost:8080 in your browser."
print_color "yellow" "Note: The SSH tunnel forwards ports 8080 (UI) and 4567 (debugger-server)."

# Attempt to open the browser (for local machine only)
print_color "yellow" "\nAttempting to open http://localhost:8080 (for local machine only)..."
if [[ "$OSTYPE" == "darwin"* ]]; then
    if ! open http://localhost:8080; then
        print_color "yellow" "Browser could not be opened automatically. Please follow the instructions above."
    fi
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    if ! xdg-open http://localhost:8080 2>/dev/null; then
        print_color "yellow" "Browser could not be opened automatically. Please follow the instructions above."
    fi
elif [[ "$OSTYPE" == "msys" || "$OSTYPE" == "cygwin" ]]; then
    if ! start http://localhost:8080; then
        print_color "yellow" "Browser could not be opened automatically. Please follow the instructions above."
    fi
else
    print_color "yellow" "Please follow the instructions above to access the demo."
fi

print_color "green" "\nSetup complete! To stop the demo, run: docker compose down"
print_color "yellow" "If using an SSH tunnel, close the terminal running the SSH command to end the tunnel."