# LLM Agent Debugger
This repository contains a **Beta version** of the **LLM Agent Debugger**, developed at the Software Lab of the University of Stuttgart. The debugger is designed to facilitate interactive inspection and control of large language model (LLM) agents during execution.

## Project Structure

- **Debugger**: Contains the Python-based debugger server and the client API (`debugger_server.py`, `debugger_client.py`)
- **UI**: A Vue-based web interface for interacting with the debugger

## Getting Started

### 1. Prerequisites

- Python 3.8 or higher
- Node.js 18.18 or higher and npm (for the UI)

### 2. Installation

Navigate to the `Debugger` directory:

```bash
cd Debugger
```

#### Option A: System-Wide Python Installation

```bash
pip install -r requirements.txt
```

#### Option B: Virtual Environment (Recommended)

```bash
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows

pip install -r requirements.txt
```

### 3. Launching the Debugger Server

```bash
python3 debugger_server.py
```

## Using the Debugger

### API Integration

To instrument your own LLM agent, use the functions provided in `debugger_client.py`.

## UI: Vue Web Interface

### Location

The UI code is located in the `UI` folder.

### Setup and Launch

#### Linux / macOS

```bash
cd ../UI
npm install
npm run serve
```

#### Windows

```powershell
cd ..\UI
npm install
npm run serve
```

The UI will be available at `http://localhost:<port>`, where `<port>` is specified in the terminal output.

---

## Contact

For questions or contributions, please open an issue or contact the maintainer.
