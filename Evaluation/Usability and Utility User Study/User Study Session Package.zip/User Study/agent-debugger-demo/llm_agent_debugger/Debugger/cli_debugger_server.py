import argparse
from pathlib import Path
from typing import List
from server_types import Run
import logging
from server_version import DEBUGGER_SERVER_VERSION

logger = logging.getLogger('DebuggerServer')

def parse_arguments() -> argparse.Namespace:
    """
    Parses command line arguments for the Debugger Server.

    :return: Parsed command line arguments.
    :rtype: argparse.Namespace
    """
    parser = argparse.ArgumentParser(description='Debugger Server Command Line Interface')
    parser.add_argument('--host', type=str, default='localhost',
                        help='Hostname for the debugger server (default: localhost)')
    parser.add_argument('--client-port', type=int, default=8765,
                        help='Port for debugger client connection (default: 8765)')
    parser.add_argument('--ui-port', type=int, default=4567,
                        help='Port for UI component connection (default: 4567)')
    parser.add_argument('-r', '--runs', type=str, nargs='*', default=[],
                        help='Run files to load on startup')
    return parser.parse_args()

def load_runs(server: 'DebuggerServer', run_files: List[str]) -> None:
    """
    Loads run files into the debugger server's run history.

    :param DebuggerServer server: The debugger server instance to load runs into.
    :param List[str] run_files: List of paths to run files to be loaded.
    """
    for run_path in run_files:
        try:
            file_path = Path(run_path)
            if not file_path.exists():
                logger.warning(f"Run file not found: {run_path}")
                continue
            
            with file_path.open('rb') as file:
                data = file.read()
                run = Run.from_bytes(data, is_base64_encoded=False)
                if run.server_version == DEBUGGER_SERVER_VERSION:
                    server.run_history.append(run)
                    logger.info(f"Successfully loaded run: {run_path}")
                else:
                    raise Exception('Run file incompatible with current server version')
                
        except ValueError as e:
            logger.warning(f"Invalid run file format in {run_path}: {str(e)}")
            continue
        except Exception as e:
            logger.warning(f"Failed to load run file {run_path}: {str(e)}")
            continue