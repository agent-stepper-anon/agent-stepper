from Client.debugger_client import AgentDebugger
import random

class LLM:
    
    answers = {
        'hello world!': "Hello, Sir! 🌍 \n How can I assist you today?",
        'what is the capital of france?': "The capital of France is Paris.",
        'who won the world cup in 2018?': "France won the FIFA World Cup in 2018.",
        'what is 2 + 2?': "2 + 2 equals 4.",
        'tell me a joke': "Why don’t scientists trust atoms? Because they make up everything!",
        'who are you?': "I'm a dummy LLM created to simulate responses.",
        'how do you make coffee?': "To make coffee: boil water, add ground coffee to a filter, pour hot water over it, and enjoy!",
        'what is the speed of light?': "The speed of light is approximately 299,792 kilometers per second.",
        'how do i reverse a list in python?': "You can reverse a list in Python using `my_list[::-1]` or `my_list.reverse()`.",
        'goodbye': "Goodbye! Have a great day!",
        'what is ai?': "AI stands for Artificial Intelligence, the simulation of human intelligence in machines.",
    }
    
    def completion(prompt: str) -> str:
        key = prompt.lower().strip()
        if key in LLM.answers:
            return LLM.answers[key]
        else:
            return "Sorry, I can't help you with that."


def main():
    with AgentDebugger(program_name='My Agent Program', address='localhost', port='8765', agent_workspace_path='agent_workspace') as debugger:
        for i in range(1, 3):
            #prompt = debugger.begin_llm_query_breakpoint(random.choice(list(LLM.answers.keys())))
            #print(f'Prompt: {prompt}')
            #response = debugger.end_llm_query_breakpoint(LLM.completion(prompt))
            #print(f'Response: {response}')
            #debugger.begin_tool_invocation_breakpoint('write_to_file', {'path': 'logs.txt', 'content': response})
            #debugger.end_tool_invocation_breakpoint('Success (0)')
            input('Make changes to repository, press any key to continue...')
            debugger.commit_agent_changes()
        
        prompt = debugger.begin_llm_query_breakpoint({'prompt': 'Hello world!', 'role': 'user'})
        print(f'Prompt: {prompt}')
        response = debugger.end_llm_query_breakpoint({'response': 'Hello world indeed!', 'role': 'agent'})
        print(f'Response: {response}')
    


if __name__ == "__main__":
    main()