# LLM Agent Debugger Demo

A tool for debugging language model agents with a debugger server, web UI, and repair agent, run via Docker Compose.

## Prerequisites
- **Docker and Docker Compose**: Install from [docker.com](https://docs.docker.com/get-docker/).
- **Git**: Install from [git-scm.com](https://git-scm.com/downloads) (if cloning repository).
- **SSH Client (for remote)**: Included in Linux/macOS; on Windows, use PuTTY or enable OpenSSH.

## Setup

### 1. Get the Code
**Option 1: Clone Repository and Submodules**
```bash
git clone <repository-url>
cd <repository-directory>
git submodule init
git submodule update
```
Submodules:
- `llm_agent_debugger`: Debugger and UI code (`git@github.com:sola-st/bachelor-thesis-robert-hutter.git`, prototyping branch).
- `repair_agent`: Repair agent code (`git@github.com:Robert-Hutter/DebuggingRepairAgent.git`).

**Option 2: Download Latest Release**
1. Download the latest release zip from [repository releases](<repository-release-url>).
2. Extract the zip file (includes pre-packaged submodules).
3. Navigate to the extracted directory: `cd <extracted-directory>`.

### 2. Run the Demo
1. Make the script executable (Linux/macOS):
   ```bash
   chmod +x start-demo.sh
   ```
2. Run:
   ```bash
   ./start-demo.sh
   ```
3. Access:
   - **Local**: Open [http://localhost:8080](http://localhost:8080) in a browser.
   - **Remote**:
     1. In a new local terminal, run:
        ```bash
        ssh -L 8080:localhost:8080 <remote-host>
        ```
        Replace `<remote-host>` with hostname/IP (e.g., `user@192.168.1.100`).
     2. Keep the terminal open.
     3. Open [http://localhost:8080](http://localhost:8080) in a browser.

### 3. Stop the Demo
```bash
docker compose down
```
Close the SSH terminal if used.

## Troubleshooting
- **No Docker/Compose**: Verify with `docker --version` and `docker compose --version`.
- **Submodule issues (Option 1)**: Ensure SSH keys allow GitHub access; rerun `git submodule update`.
- **Cannot access http://localhost:8080**:
  - Local: Confirm containers run (`docker ps`) and ports 8080 are free.
  - Remote: Verify SSH tunnel is active.

## Notes
- Remote access requires an SSH tunnel for ports 8080 (UI).
- Ensure ports are not firewalled and internet is active for OpenAI API.